# Blake paper 0.5.0 native-render reproduction

This archive reproduces the 94-page public working draft's native rendering.
It contains frozen manuscript/configuration/variables, aggregate and mathematical
graphics, generated cover, producer sources, software 0.7 assets and exact hashes.
Provider transcriptions, XML, images, private indexes, corpus stores, backups and
provider-image mosaics are excluded. This is not a reconstruction of the corpus.

The retained analytical producer is 0.2.0rc1; the SDK is 0.7.0 at Git
263d7c83abe6f1309a64af3285a683c1b7672269. Frozen authoring guides retain their
captured state; current operating guidance belongs to the repository's docs.
The authoritative body inputs are prepared-publication.json's source_order,
not every Markdown guidance file in the preparation capture.

Extract into a fresh external epoch. Verify bundle-manifest.json's declared
members with reproduce/verify_bundle.py. Authenticating the publisher requires
the caller-held archive SHA from the repository delivery record, not this
self-contained manifest alone. Select the exact template source
efce6d6f5b3c4e8e2bbf92d8250855a0a9389ae8 and a separately locked compatible
external Python 3.14 rendering environment. Set TEMPLATE_ROOT/TEMPLATE_ENV.

uv run --no-project --offline --python "${TEMPLATE_ENV}/bin/python" python -B reproduce/verify_bundle.py .
UV_PROJECT_ENVIRONMENT="${TEMPLATE_ENV}" UV_PYTHON="${TEMPLATE_ENV}/bin/python" uv run --no-sync --frozen --project "${TEMPLATE_ROOT}" python -B reproduce/render_native.py --template-root "${TEMPLATE_ROOT}" --stage paper

Use supported repository/common-store admission and external TMP/caches; verify
both interpreter prefixes. The adapter uses the actual pinned PDF/web writers
and admitted CSS hook; generated TeX is not edited. An occupied native epoch
refuses before any writer. Preserve the original output and extract a new epoch.

Expected PDF SHA-256: 812e53237b40f808b4502e3dd358cbee5cda7d587e493ba95e41f02c11ad03eb
Expected HTML SHA-256: ec90070f2d696ddef7a5d232367263e2676e70f007696d87711bdaf5413f5160

This draft uses the concept DOI 10.5281/zenodo.21047573. The actual deposited
0.4.0 paper and its version DOI 10.5281/zenodo.23770249 remain separate until
the next authenticated publication and download readback. Software, source,
native rendering, scholarship, rights, hosted CI and publication are distinct.
