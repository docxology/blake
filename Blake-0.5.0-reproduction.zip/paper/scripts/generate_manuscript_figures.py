#!/usr/bin/env python3
"""Thin orchestrator: generate manuscript figures for blake.

Draws the registered manuscript figures into ``output/figures/``. Analytical
figures read the explicitly selected saved-evidence root; source-derived method
illustrations use the focused ``manuscript_tools`` builders. Keep the retained
analysis producer and its outputs unchanged when preparing a new display epoch.

Exit codes:
    0   all figures written
    1   unexpected error (e.g. analysis_output/ missing)
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

_PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_PROJECT_ROOT))


def main() -> int:
    from manuscript_tools.cover import generate_cover
    from manuscript_tools.figures import generate_all_figures

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--evidence-root",
        type=str,
        default=os.environ.get("BLAKE_MANUSCRIPT_EVIDENCE_ROOT"),
        help="Explicit read-only saved-evidence root; defaults to this authoring tree",
    )
    parser.add_argument(
        "--public-only",
        action="store_true",
        help=(
            "Generate only the aggregate figures used by the public paper; "
            "exclude source-image mosaics."
        ),
    )
    args = parser.parse_args()
    cover_paths = generate_cover(_PROJECT_ROOT)
    written = generate_all_figures(
        _PROJECT_ROOT, public_only=args.public_only, evidence_root=args.evidence_root
    )
    for path in cover_paths.values():
        print(str(path))
    for path in written:
        print(str(path))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
