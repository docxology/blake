"""Verify the declared public native-replay inputs without invoking a writer."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath


def verify(root: Path) -> int:
    root = root.resolve(strict=True)
    manifest_path = root / "bundle-manifest.json"
    if manifest_path.is_symlink():
        raise ValueError("bundle_manifest_symlink")
    manifest = json.loads(manifest_path.read_text())
    if (
        not isinstance(manifest, dict)
        or type(manifest.get("schema_version")) is not int
        or manifest["schema_version"] != 1
    ):
        raise ValueError("bundle_manifest_schema")
    members = manifest.get("members")
    if not isinstance(members, dict) or not members:
        raise ValueError("bundle_manifest_members")
    for name, record in members.items():
        if not isinstance(name, str) or not isinstance(record, dict):
            raise ValueError("bundle_member_record")
        relative = PurePosixPath(name)
        if (
            relative.is_absolute()
            or not relative.parts
            or any(part in {".", ".."} for part in relative.parts)
            or str(relative) != name
            or "\\" in name
        ):
            raise ValueError("bundle_member_path")
        source = root.joinpath(*relative.parts)
        if any(
            root.joinpath(*relative.parts[:index]).is_symlink()
            for index in range(1, len(relative.parts) + 1)
        ):
            raise ValueError("bundle_member_symlink: " + name)
        if not source.is_file() or not source.resolve().is_relative_to(root):
            raise ValueError("bundle_member_missing: " + name)
        expected_size = record.get("size")
        expected_sha = record.get("sha256")
        if type(expected_size) is not int or expected_size < 0:
            raise ValueError("bundle_member_size_record")
        if (
            not isinstance(expected_sha, str)
            or len(expected_sha) != 64
            or any(character not in "0123456789abcdef" for character in expected_sha)
        ):
            raise ValueError("bundle_member_digest_record")
        actual = source.read_bytes()
        if (
            len(actual) != expected_size
            or hashlib.sha256(actual).hexdigest() != expected_sha
        ):
            raise ValueError("bundle_member_changed: " + name)
    return len(members)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    arguments = parser.parse_args()
    count = verify(arguments.root)
    print(
        json.dumps(
            {
                "declared_members_verified": count,
                "scope": "Internal byte consistency; publisher identity requires the caller-held archive pin",
            }
        )
    )


if __name__ == "__main__":
    main()
